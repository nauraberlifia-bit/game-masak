# COOKING WORLD

Browser cooking game yang dibuat dengan HTML, CSS, JavaScript.

## Cara menjalankan
Buka index.html menggunakan browser atau VS Code Live Server.

## Deploy
Upload seluruh isi folder ke GitHub.
Aktifkan GitHub Pages melalui Settings > Pages.
Pilih Deploy from a branch, branch main, folder root.

Game menggunakan LocalStorage untuk menyimpan progres.
